# SI-GuidedProject-603590-1697639379

**THIS IS A GUIDED SMARTINTERNZ PROJECT**

PROJECT TITLE:
**Online Shoppers Intentions Using ML**

SKILLS REQUIRED:
CNN, ML, WEB APP FLASK

PROJECT DESCRIPTION:
Online shopping is the activity or action of buying products or services over the Internet. 
It means going online, landing on a seller’s website, selecting something, and arranging for its delivery. 
The buyer either pays for the good or service online with a credit or debit card or upon delivery. 
The term does not only include buying things online but also searching for them online. 
In other words, I may have been engaged in online shopping but did not buy anything.
We are going to predict whether the customer will buy the product or just go window shopping . 
Here, We will be using classification algorithms such as Logistic Regression , Random forest, & Clustering algorithm K-Means.
We will train and test the data with these algorithms. From this the best model is selected and saved in pkl format.

1.IDEATION PHASE FOLDER IS UPLOADED ON 18TH OCTOBER 2023
2.PROJECT DESIGN PHASE FOLDER IS UPLOADED ON 23RD OCTOBER 2023
3.PROJECT PLANNING PHASE FOLDER UPLOADED ON 27TH OCTOBER 2023
4. PROJECT DEVELOPEMNT PHASE FOLDER UPLOADED ON 9TH NOVEMBER 2023
5. PROJECT FINAL PERFORMANCE PHASE FOLDER UPLOADED ON 9TH NOVEMBER 2023

Video demonstration link : https://drive.google.com/drive/folders/1L08COrbg9MNJjkfCNww3xDCZdrYOmWII?usp=drive_link
